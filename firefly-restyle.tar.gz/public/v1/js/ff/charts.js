/*
 * charts.js
 * Copyright (c) 2019 james@firefly-iii.org
 *
 * This file is part of Firefly III (https://github.com/firefly-iii).
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as
 * published by the Free Software Foundation, either version 3 of the
 * License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */
var allCharts = {};


/*
 Make some colours:
 */
var colourSet = [
    [43, 127, 166], // chart-1, blue
    [52, 179, 160], // chart-2, teal
    [242, 163, 58], // chart-3, amber
    [139, 124, 246], // chart-4, violet
    [240, 106, 127], // chart-5, rose
    [161, 161, 170], // chart-6, zinc
    [53, 124, 165],
    [0, 141, 76], // green
    [219, 139, 11],
    [202, 25, 90], // paars rood-ish #CA195A
    [85, 82, 153],
    [66, 133, 244],
    [219, 68, 55], // red #DB4437
    [244, 180, 0],
    [15, 157, 88],
    [171, 71, 188],
    [0, 172, 193],
    [255, 112, 67],
    [158, 157, 36],
    [92, 107, 192],
    [240, 98, 146],
    [0, 121, 107],
    [194, 24, 91]
];

var fillColors = [];

for (var i = 0; i < colourSet.length; i++) {
    fillColors.push("rgba(" + colourSet[i][0] + ", " + colourSet[i][1] + ", " + colourSet[i][2] + ", 0.5)");
}

Chart.defaults.global.legend.display = false;
Chart.defaults.global.animation.duration = 0;
Chart.defaults.global.responsive = true;
Chart.defaults.global.maintainAspectRatio = false;

/*
 Look & feel that matches the theme tokens (sass/theme/_tokens.scss):
 smooth lines, no points until hover, dashed grid and a card-like tooltip.
 */
function themeColor(name, fallback) {
    var value = getComputedStyle(document.documentElement).getPropertyValue(name).trim();
    return '' === value ? fallback : value;
}

(function () {
    "use strict";
    var muted = themeColor('--ff-muted-foreground', '#71717a');
    var border = themeColor('--ff-border', '#e4e4e7');
    var foreground = themeColor('--ff-foreground', '#09090b');
    var popover = themeColor('--ff-popover', '#ffffff');
    var card = themeColor('--ff-card', '#ffffff');

    Chart.defaults.global.defaultFontFamily = getComputedStyle(document.body).fontFamily;
    Chart.defaults.global.defaultFontColor = muted;
    Chart.defaults.global.defaultFontSize = 12;
    Chart.defaults.global.hover.mode = 'index';
    Chart.defaults.global.hover.intersect = false;

    Chart.defaults.global.elements.line.tension = 0.4;
    Chart.defaults.global.elements.line.borderWidth = 2.5;
    Chart.defaults.global.elements.line.borderCapStyle = 'round';
    Chart.defaults.global.elements.point.radius = 0;
    Chart.defaults.global.elements.point.hoverRadius = 5;
    Chart.defaults.global.elements.point.hitRadius = 8;
    Chart.defaults.global.elements.point.hoverBorderWidth = 2;
    Chart.defaults.global.elements.rectangle.borderWidth = 0;
    Chart.defaults.global.elements.arc.borderWidth = 2;
    Chart.defaults.global.elements.arc.borderColor = card;

    Chart.defaults.global.tooltips.mode = 'index';
    Chart.defaults.global.tooltips.intersect = false;
    Chart.defaults.global.tooltips.backgroundColor = popover;
    Chart.defaults.global.tooltips.titleFontColor = foreground;
    Chart.defaults.global.tooltips.bodyFontColor = foreground;
    Chart.defaults.global.tooltips.footerFontColor = muted;
    Chart.defaults.global.tooltips.borderColor = border;
    Chart.defaults.global.tooltips.borderWidth = 1;
    Chart.defaults.global.tooltips.xPadding = 10;
    Chart.defaults.global.tooltips.yPadding = 10;
    Chart.defaults.global.tooltips.cornerRadius = 8;
    Chart.defaults.global.tooltips.caretSize = 0;
    Chart.defaults.global.tooltips.multiKeyBackground = 'transparent';

    Chart.defaults.global.legend.labels.usePointStyle = true;
    Chart.defaults.global.legend.labels.boxWidth = 8;

    Chart.defaults.scale.gridLines.color = border;
    Chart.defaults.scale.gridLines.zeroLineColor = border;
    Chart.defaults.scale.gridLines.borderDash = [3, 3];
    Chart.defaults.scale.gridLines.drawBorder = false;
    Chart.defaults.scale.gridLines.drawTicks = false;
    Chart.defaults.scale.ticks.padding = 8;
})();

/**
 *
 * @param data
 * @returns {{}}
 */
function colorizeData(data, chartType, ctx) {
    var newData = {};
    newData.datasets = [];
    var card = themeColor('--ff-card', '#ffffff');

    for (var loop = 0; loop < data.count; loop++) {
        newData.labels = data.labels;
        var dataset = data.datasets[loop];
        var colour = colourSet[loop % colourSet.length];
        var solid = "rgb(" + colour[0] + ", " + colour[1] + ", " + colour[2] + ")";
        dataset.borderColor = solid;
        dataset.pointBackgroundColor = solid;
        dataset.pointHoverBackgroundColor = solid;
        dataset.pointHoverBorderColor = card;
        dataset.backgroundColor = solid;
        dataset.fill = false;

        // line charts with only a few lines get a soft gradient below the line.
        if ('line' === chartType && data.count <= 3 && ctx) {
            var gradient = ctx.createLinearGradient(0, 0, 0, ctx.canvas.clientHeight || 300);
            gradient.addColorStop(0, "rgba(" + colour[0] + ", " + colour[1] + ", " + colour[2] + ", 0.28)");
            gradient.addColorStop(1, "rgba(" + colour[0] + ", " + colour[1] + ", " + colour[2] + ", 0)");
            dataset.backgroundColor = gradient;
            dataset.fill = 'origin';
        }
        newData.datasets.push(dataset);
    }
    return newData;
}

/**
 * Function to draw a line chart:
 * @param URL
 * @param container
 */
function lineChart(URL, container) {
    "use strict";

    var colorData = true;
    var options = $.extend(true, {}, defaultChartOptions);
    var chartType = 'line';

    drawAChart(URL, container, chartType, options, colorData);
}

/**
 * Function to draw a line chart that doesn't start at ZERO.
 * @param URL
 * @param container
 */
function lineNoStartZeroChart(URL, container) {
    "use strict";

    var colorData = true;
    var options = $.extend(true, {}, defaultChartOptions);
    var chartType = 'line';
    options.scales.yAxes[0].ticks.beginAtZero = false;

    drawAChart(URL, container, chartType, options, colorData);
}

/**
 * Overrules the currency the line chart is drawn in.
 *
 * @param URL
 * @param container
 */
function otherCurrencyLineChart(URL, container, currencySymbol) {
    "use strict";

    var colorData = true;

    var newOpts = {
        scales: {
            xAxes: [
                {
                    gridLines: {
                        display: false
                    },
                    ticks: {
                        // break ticks when too long.
                        callback: function (value, index, values) {
                            return formatLabel(value, 20);
                        }
                    }
                }
            ],
            yAxes: [{
                display: true,
                //hello: 'fresh',
                ticks: {
                    callback: function (tickValue) {
                        "use strict";
                        // use first symbol or null:
                        return accounting.formatMoney(tickValue);

                    },
                    beginAtZero: true
                }
            }]
        },
    };

    //var options = $.extend(true, newOpts, defaultChartOptions);
    var options = $.extend(true, defaultChartOptions, newOpts);

    // console.log(options);
    var chartType = 'line';

    drawAChart(URL, container, chartType, options, colorData);
}

/**
 * Function to draw a chart with double Y Axes and stacked columns.
 *
 * @param URL
 * @param container
 */
function doubleYChart(URL, container) {
    "use strict";

    var colorData = true;
    var options = $.extend(true, {}, defaultChartOptions);
    options.scales.yAxes = [
        // y axis 0:
        {
            display: true,
            ticks: {
                callback: function (tickValue) {
                    "use strict";
                    return accounting.formatMoney(tickValue);

                },
                beginAtZero: true
            },
            position: "left",
            "id": "y-axis-0"
        },
        // and y axis 1:
        {
            display: true,
            ticks: {
                callback: function (tickValue) {
                    "use strict";
                    return accounting.formatMoney(tickValue);

                },
                beginAtZero: true
            },
            position: "right",
            "id": "y-axis-1"
        }

    ];
    options.stacked = true;
    options.scales.xAxes[0].stacked = true;

    var chartType = 'bar';

    drawAChart(URL, container, chartType, options, colorData);
}

/**
 * Function to draw a chart with double Y Axes and non stacked columns.
 *
 * @param URL
 * @param container
 */
function doubleYNonStackedChart(URL, container) {
    "use strict";

    var colorData = true;
    var options = $.extend(true, {}, defaultChartOptions);
    options.scales.yAxes = [
        // y axis 0:
        {
            display: true,
            ticks: {
                callback: function (tickValue) {
                    "use strict";
                    return accounting.formatMoney(tickValue);

                },
                beginAtZero: true
            },
            position: "left",
            "id": "y-axis-0"
        },
        // and y axis 1:
        {
            display: true,
            ticks: {
                callback: function (tickValue) {
                    "use strict";
                    return accounting.formatMoney(tickValue);

                },
                beginAtZero: true
            },
            position: "right",
            "id": "y-axis-1"
        }

    ];
    var chartType = 'bar';

    drawAChart(URL, container, chartType, options, colorData);
}


/**
 *
 * @param URL
 * @param container
 */
function columnChart(URL, container) {
    "use strict";
    var colorData = true;
    var options = $.extend(true, {}, defaultChartOptions);
    var chartType = 'bar';

    drawAChart(URL, container, chartType, options, colorData);
}


/**
 *
 * @param URL
 * @param container
 */
function columnChartCustomColours(URL, container) {
    "use strict";
    var colorData = false;
    var options = $.extend(true, {}, defaultChartOptions);
    var chartType = 'bar';

    drawAChart(URL, container, chartType, options, colorData);

}

/**
 *
 * @param URL
 * @param container
 */
function stackedColumnChart(URL, container) {
    "use strict";
    console.log('stackedColumnChart(' + URL + ', ' + container + ')');

    var colorData = true;
    var options = $.extend(true, {}, defaultChartOptions);

    options.stacked = true;
    options.scales.xAxes[0].stacked = true;
    options.scales.yAxes[0].stacked = true;

    var chartType = 'bar';

    drawAChart(URL, container, chartType, options, colorData);
}

/**
 *
 * @param URL
 * @param container
 */
function pieChart(URL, container) {
    "use strict";

    var colorData = false;
    var options = $.extend(true, {}, defaultPieOptions);
    options.cutoutPercentage = 68;
    var chartType = 'pie';

    drawAChart(URL, container, chartType, options, colorData);

}

/**
 *
 * @param URL
 * @param container
 */
function multiCurrencyPieChart(URL, container) {
    "use strict";

    var colorData = false;
    var options = $.extend(true, {}, pieOptionsWithCurrency);
    options.cutoutPercentage = 68;
    var chartType = 'pie';

    drawAChart(URL, container, chartType, options, colorData);

}

/**
 * @param URL
 * @param container
 * @param chartType
 * @param options
 * @param colorData
 * @param today
 */
function drawAChart(URL, container, chartType, options, colorData) {
    console.log('drawAChart(' + URL + ', ' + container + ')');
    var containerObj = document.getElementById(container);
    if (null === containerObj) {
        console.log('Return because NULL');
        return;
    }
    if (containerObj.length === 0) {
        console.log('Return because 0');
        return;
    }
    window.axios.get(URL).then(function (response) {
        //console.log('GET drawAChart('+URL+', '+container+')');
        containerObj.classList.remove('general-chart-error');
        var data = response.data;
        // if result is empty array, or the labels array is empty, show error.
        // console.log(URL);
        // console.log(data.length);
        // console.log(typeof data.labels);
        // console.log(data.labels.length);
        if (
            // is undefined
            typeof data === 'undefined' ||
            // is empty
            0 === data.length ||
            // isn't empty but contains no labels
            (typeof data === 'object' && typeof data.labels === 'object' && 0 === data.labels.length)
        ) {
            // console.log('NODATA drawAChart('+URL+', '+container+')');
            // console.log(data);
            // remove the chart container + parent
            var holder = document.getElementById(container).parentNode.parentNode;
            if (holder.classList.contains('card') || holder.classList.contains('card-body')) {
                // console.log('found holder');
                // find box-body:
                var boxBody;
                if (!holder.classList.contains('card-body')) {
                    // console.log('Look for card body', holder.querySelector('.card-body').length);
                    boxBody = holder.querySelector('.card-body');
                } else {
                    boxBody = holder;
                }
                // console.log('found box body', boxBody);
                // boxBody.innerHtml = '<p><em>'+noDataForChart+'</em></p>';
                boxBody.innerHTML = '<p><em>' + noDataForChart + '</em></p>';
                //boxBody.empty().append($('<p>').append($('<em>').text(noDataForChart)));
            }
            // console.log('return');
            return;
        }

        if (colorData) {
            data = colorizeData(data, chartType, document.getElementById(container).getContext("2d"));
        }

        if (allCharts.hasOwnProperty(container)) {
            allCharts[container].data.datasets = data.datasets;
            allCharts[container].data.labels = data.labels;
            allCharts[container].update();
        } else {
            // new chart!
            var ctx = document.getElementById(container).getContext("2d");
            var chartOpts = {
                type: chartType,
                data: data,
                options: options,
                lineAtIndex: [],
                annotation: {},
            };
            if (typeof drawVerticalLine !== 'undefined') {
                if (drawVerticalLine !== '') {
                    // draw line using annotation plugin.
                    chartOpts.options.annotation = {
                        annotations: [{
                            type: 'line',
                            id: 'a-line-1',
                            mode: 'vertical',
                            scaleID: 'x-axis-0',
                            value: drawVerticalLine,
                            borderColor: lineColor,
                            borderWidth: 1,
                            label: {
                                backgroundColor: 'rgba(0,0,0,0)',
                                fontFamily: "sans-serif",
                                fontSize: 12,
                                fontColor: lineTextColor,
                                position: "right",
                                xAdjust: -20,
                                yAdjust: -125,
                                enabled: true,
                                content: todayText
                            }
                        }]
                    };
                }
            }
            allCharts[container] = new Chart(ctx, chartOpts);
        }

    }).catch(function (reason) {
        // console.error('Add error because error with chart.', reason);
        document.getElementById(container).classList.add('general-chart-error');
    });
}
