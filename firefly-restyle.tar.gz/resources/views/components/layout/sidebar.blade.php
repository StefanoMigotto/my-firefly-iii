<ul
    class="nav sidebar-menu flex-column"
    data-lte-toggle="treeview"
    role="navigation"
    aria-label="Main navigation"
    data-accordion="false"
    id="navigation"
    x-data="sidebar"
>
    <li class="nav-item search-xl">
        <form action="{{ route('search.index') }}" method="get" class="ff-sidebar-search" role="search">
            <label class="visually-hidden" for="searchInput">{{ trans('firefly.searchPlaceholder') }}</label>
            <em class="bi bi-search" aria-hidden="true"></em>
            <input autocomplete="off" type="search" id="searchInput" name="search" class="form-control" placeholder="{{ trans('firefly.searchPlaceholder') }}" value="{{ $query ?? '' }}" spellcheck="false">
            <button type="submit" name="go" id="search-btn" class="visually-hidden">{{ __('firefly.search') }}</button>
        </form>
    </li>
    <li class="nav-item search-xs" style="display:none;">
        <a href="{{ route('search.index') }}" class="nav-link {{ \FireflyIII\Support\Blade\Navigation::menuItemActive('search.index') }}">
            <em class="nav-icon bi bi-search"></em>
            <p>{{ __('firefly.search') }}</p>
        </a>
    </li>
    <li class="nav-item">
        <a href="{{ route('index') }}" class="nav-link {{ \FireflyIII\Support\Blade\Navigation::menuItemActive('index') }}">
            <em class="nav-icon bi bi-speedometer"></em>
            <p>{{ __('firefly.dashboard') }}</p>
        </a>
    </li>
    <li class="nav-header">{{ __('firefly.financial_control') }}</li>
    <li class="nav-item">
        <a href="{{ route('budgets.index') }}" class="nav-link {{ menu_item_active_partial('budgets.') }}">
            <em class="nav-icon bi bi-pie-chart"></em>
            <p>
                {{ __('firefly.budgets') }}
            </p>
        </a>
    </li>
    <li class="nav-item">
        <a href="{{ route('subscriptions.index') }}" class="nav-link {{ menu_item_active_partial('subscriptions.') }}">
            <em class="nav-icon bi bi-calendar"></em>
            <p>
                {{ __('firefly.subscriptions') }}
            </p>
        </a>
    </li>
    <li class="nav-item">
        <a href="{{ route('piggy-banks.index') }}" class="nav-link {{ menu_item_active_partial('piggy-banks.') }}">
            <em class="nav-icon bi bi-bullseye"></em>
            <p>
                {{ __('firefly.piggyBanks') }}
            </p>
        </a>
    </li>
    <li class="nav-header">{{ __('firefly.accounting') }}</li>

    <li class="nav-item {{ menu_open_partial('transactions.') }}">
        <a href="#" class="nav-link">
            <em class="nav-icon bi bi-wallet"></em>
            <p>
                {{ __('firefly.transactions') }}
                <em class="nav-arrow bi bi-chevron-right"></em>
            </p>
        </a>
        <ul class="nav nav-treeview">
            <li class="nav-item sub-nav-item">
                <a href="{{ route('transactions.index', ['withdrawal']) }}" class="nav-link {{ menu_sub_item_active('transactions.index','withdrawal') }}">
                    <em class="nav-icon bi bi-arrow-left"></em>
                    <p>{{ __('firefly.expenses') }}</p>
                </a>
            </li>
            <li class="nav-item sub-nav-item">
                <a href="{{ route('transactions.index', ['deposit']) }}" class="nav-link {{ menu_sub_item_active('transactions.index','deposit') }}">
                    <em class="nav-icon bi bi-arrow-right"></em>
                    <p>{{ __('firefly.income') }}</p>
                </a>
            </li>
            <li class="nav-item sub-nav-item">
                <a href="{{ route('transactions.index', ['transfers']) }}" class="nav-link {{ menu_sub_item_active('transactions.index','transfers') }}">
                    <em class="nav-icon bi bi-arrow-left-right"></em>
                    <p>{{ __('firefly.transfers') }}</p>
                </a>
            </li>
            <li class="nav-item sub-nav-item">
                <a href="{{ route('transactions.index', ['all']) }}" class="nav-link {{ menu_sub_item_active('transactions.index','all') }}">
                    <em class="nav-icon bi bi-arrow-repeat"></em>
                    <p>{{ __('firefly.all_transactions') }}</p>
                </a>
            </li>
        </ul>
    </li>
    <li class="nav-item {{ menu_open_partial('rules.') }} {{ menu_open_partial('rule-groups.') }} {{ menu_open_partial('webhooks.') }}  {{ menu_open_partial('recurring.') }}">
        <a href="#" class="nav-link">
            <em class="nav-icon bi bi-cpu"></em>
            <p>
                {{ __('firefly.automation') }}
                <em class="nav-arrow bi bi-chevron-right"></em>
            </p>
        </a>
        <ul class="nav nav-treeview">
            <li class="nav-item sub-nav-item">
                <a href="{{ route('rules.index') }}" class="nav-link {{ menu_item_active_partial('rules.') }} {{ menu_item_active_partial('rule-groups.') }}">
                    <em class="nav-icon bi bi-shuffle"></em>
                    <p>{{__('firefly.rules')}}</p>
                </a>
            </li>
            <li class="nav-item sub-nav-item">
                <a href="{{ route('recurring.index') }}" class="nav-link {{ menu_item_active_partial('recurring.') }}">
                    <em class="nav-icon bi bi-paint-bucket"></em>
                    <p>{{__('firefly.recurrences') }}</p>
                </a>
            </li>
            @if(true === $featuringWebhooks)
            <li class="nav-item sub-nav-item">
                <a href="{{ route('webhooks.index') }}" class="nav-link {{ menu_item_active_partial('webhooks.') }}">
                    <em class="nav-icon bi bi-lightning"></em>
                    <p>{{ __('firefly.webhooks') }}</p>
                </a>
            </li>
            @endif
            @if(false === $featuringWebhooks)
                <li class="nav-item sub-nav-item">
                    <span class="nav-link">
                        <em class="nav-icon bi bi-lightning"></em>
                        <p>{{ __('firefly.webhooks') }} ({{ trans('firefly.webhooks_menu_disabled') }})</p>
                    </span>
                </li>
            @endif
        </ul>
    </li>
    <li class="nav-header">{{ __('firefly.organization') }}</li>
    <li class="nav-item {{ menu_open_partial('accounts.') }}">
        <a href="#" class="nav-link">
            <em class="nav-icon bi bi-credit-card"></em>
            <p>
                {{__('firefly.accounts')}}
                <em class="nav-arrow bi bi-chevron-right"></em>
            </p>
        </a>
        <ul class="nav nav-treeview">
            <li class="nav-item sub-nav-item">
                <a href="{{ route('accounts.index', ['asset']) }}" class="nav-link {{ menu_sub_item_active('accounts.index','asset') }}">
                    <em class="nav-icon bi bi-cash"></em>
                    <p>{{ __('firefly.asset_accounts') }}</p>
                </a>
            </li>
            <li class="nav-item sub-nav-item">
                <a href="{{ route('accounts.index', ['expense']) }}" class="nav-link {{ menu_sub_item_active('accounts.index','expense') }}">
                    <em class="nav-icon bi bi-cart"></em>
                    <p>{{trans('firefly.expense_accounts')}}</p>
                </a>
            </li>
            <li class="nav-item sub-nav-item">
                <a href="{{ route('accounts.index', ['revenue']) }}" class="nav-link {{ menu_sub_item_active('accounts.index','revenue') }}">
                    <em class="nav-icon bi bi-box-arrow-down"></em>
                    <p>{{ __('firefly.revenue_accounts') }}</p>
                </a>
            </li>
            <li class="nav-item sub-nav-item">
                <a href="{{ route('accounts.index', ['liabilities']) }}" class="nav-link {{ menu_sub_item_active('accounts.index','liabilities') }}">
                    <em class="nav-icon bi bi-ticket-detailed"></em>
                    <p>{{ __('firefly.liabilities_accounts') }}</p>
                </a>
            </li>
        </ul>
    </li>

    <li class="nav-item {{ menu_open_partial('categories.') }} {{ menu_open_partial('tags.') }} {{ menu_open_partial('object-groups.') }}">
        <a href="#" class="nav-link">
            <em class="nav-icon bi bi-tags"></em>
            <p>
                {{trans('firefly.classification')}}
                <em class="nav-arrow bi bi-chevron-right"></em>
            </p>
        </a>
        <ul class="nav nav-treeview">
            <li class="nav-item sub-nav-item">
                <a href="{{ route('categories.index') }}" class="nav-link {{ menu_item_active_partial('categories.') }}">
                    <em class="nav-icon bi bi-bookmark"></em>
                    <p>{{trans('firefly.categories')}}</p>
                </a>
            </li>
            <li class="nav-item sub-nav-item">
                <a href="{{ route('tags.index') }}" class="nav-link {{ menu_item_active_partial('tags.') }}">
                    <em class="nav-icon bi bi-tag"></em>
                    <p>{{trans('firefly.tags')}}</p>
                </a>
            </li>
            <li class="nav-item sub-nav-item">
                <a href="{{ route('object-groups.index') }}" class="nav-link {{ menu_item_active_partial('object-groups.') }}">
                    <em class="nav-icon bi bi-envelope"></em>
                    <p>{{trans('firefly.object_groups_menu_bar')}}</p>
                </a>
            </li>
        </ul>
    </li>


    <li class="nav-header">{{ __('firefly.others') }}</li>
    <li class="nav-item">
        <a href="{{ route('currencies.index') }}" class="nav-link {{ menu_item_active_partial('currencies.') }}">
            <em class="nav-icon bi bi-currency-euro"></em>
            <p>{{ __('firefly.currencies') }}</p>
        </a>
    </li>
    @if(true === $featuringCer)
    <li class="nav-item">
        <a href="{{ route('exchange-rates.index') }}" class="nav-link {{ menu_item_active_partial('exchange-rates.') }}">
            <em class="nav-icon bi bi-currency-exchange"></em>
            <p>{{ __('firefly.menu_exchange_rates_index') }}</p>
        </a>
    </li>
    @endif
    @if(false === $featuringCer)
        <li class="nav-item">
            <span class="nav-link {{ menu_item_active_partial('exchange-rates.') }}">
                <em class="nav-icon bi bi-currency-exchange"></em>
                <p>{{ __('firefly.menu_exchange_rates_index') }} ({{ trans('firefly.cer_menu_disabled') }})</p>
            </span>
        </li>
    @endif
    <li class="nav-item">
        <a href="{{ route('reports.index') }}" class="nav-link {{ menu_item_active_partial('reports.') }}">
            <em class="nav-icon bi bi-bar-chart"></em>
            <p>{{ __('firefly.reports') }}</p>
        </a>
    </li>
    <li class="nav-item">
        <a href="{{ route('export.index') }}" class="nav-link {{ menu_item_active_partial('export.') }}">
            <em class="nav-icon bi bi-upload"></em>
            <p>{{ __('firefly.export_data_menu') }}</p>
        </a>
    </li>

    @if('web' === $authGuard)
        <li class="nav-item">
            <a href="{{ route('logout') }}" @click="logoutUser" class="nav-link logout-link">
                <em class="nav-icon bi bi-person money-negative"></em>
                <p>{{ __('firefly.logout') }}</p>
            </a>
        </li>
    @endif
    @if('remote_user_guard' === $authGuard && '' !== $logoutUrl)
        <li class="nav-item">
            <a href="{{ $logoutUrl }}" class="nav-link logout-link">
                <em class="nav-icon bi bi-person money-negative"></em>
                <p>{{ __('firefly.logout') }}</p>
            </a>
        </li>
    @endif
</ul>
