<table class="table table-valign-middle table-sm table-hover tx-list">
    <thead>
    <tr>
        @if($showCategory && $showBudget)
            <td colspan="9">
                @if(method_exists($groups, 'links'))
                    {{ $groups->links('pagination.bootstrap-4') }}
                @endif
            </td>
        @endif
        @if($showCategory XOR $showBudget)
            <td colspan="8">
                @if(method_exists($groups, 'links'))
                    {{ $groups->links('pagination.bootstrap-4') }}
                @endif
            </td>
        @endif
        @if(!$showCategory && !$showBudget)
            <td colspan="7">
                @if(method_exists($groups, 'links'))
                {{ $groups->links('pagination.bootstrap-4') }}
                    @endif
            </td>
       @endif
        <td class="d-none d-md-table-cell text-end">
            <!-- Single button -->
            <div class="action-menu d-none"> <!-- d-none -->
                <button class="btn btn-sm btn-outline-secondary dropdown-toggle" type="button" id="top_action_menu" data-bs-toggle="dropdown" aria-expanded="false">
                    {{ __('firefly.actions') }}<span class="caret"></span>
                </button>
                <ul class="dropdown-menu" aria-labelledby="top_action_menu">
                    <li><a href="#" class="dropdown-item mass-edit"><span class="bi bi-pencil"></span> <span class="txt">{{ __('firefly.mass_edit') }}</span></a></li>
                    <li><a href="#" class="dropdown-item bulk-edit"><span class="bi bi-pencil-square"></span> <span class="txt">{{ __('firefly.bulk_edit') }}</span></a></li>
                    <li><a href="#" class="dropdown-item mass-delete"><span class="bi bi-trash"></span> <span class="txt">{{ __('firefly.mass_delete') }}</span></a></li>
                </ul>
            </div>
        </td>
        <td class="d-none d-md-table-cell text-end">
            <input id="list_ALL" value="1" name="select-all" type="checkbox" class="select-all form-check-inline"/>
        </td>
    </tr>
    <tr class="tx-head">
        <th class="tx-col-icon">&nbsp;</th>
        <th>{{ trans('list.description') }}</th>
        <th class="text-end">{{ trans('list.amount') }}</th>
        @if(get_app_configuration('use_running_balance', true))
            <th class="text-end d-none d-md-table-cell">{{ trans('list.running_balance') }}</th>
        @endif
        <th class="d-none d-md-table-cell">{{ trans('list.date') }}</th>
        <th class="d-none d-md-table-cell">{{ trans('list.source_account') }}</th>
        <th class="d-none d-md-table-cell">{{ trans('list.destination_account') }}</th>
        @if($showCategory)
            <th class="d-none d-md-table-cell">{{ trans('list.category') }}</th>
        @endif
        @if($showBudget)
            <th class="d-none d-md-table-cell">{{ trans('list.budget') }}</th>
        @endif
        <th class="d-none d-md-table-cell">&nbsp;</th><!-- actions -->
        <th class="d-none d-md-table-cell">&nbsp;</th><!-- checkbox -->
    </tr>
    </thead>
    <tbody>
    @foreach($groups as $group)
        @if($group['count'] > 1)
        <tr class="top-light-border">
            <td colspan="2">
                <small><strong><a href="{{ route('transactions.show', [$group['id']]) }}" title="{{ $group['title'] }}">{{ $group['title'] }}</a></strong></small>
            </td>
            <td colspan="1" class="text-end">
                {{-- Total amount of all journals in the group. --}}
                @foreach($group['sums'] as $sum)
                    @if('Deposit' === $group['transaction_type'])
                        {!! format_amount_by_symbol($sum['amount']*-1, $sum['currency_symbol'], $sum['currency_decimal_places']) !!}
                        @if($convertToPrimary && 0.0 !== (float)$sum['pc_amount'] && $primaryCurrency->id !== $sum['currency_id'])
                            (~ {!! format_amount_by_symbol($sum['pc_amount']*-1, $primaryCurrency->symbol, $primaryCurrency->decimal_places) !!})@endif{{ $loop->index !== count($group['sums'])-1 ? ',' : '' }}
                    @elseif('Transfer' === $group['transaction_type'])
                        <span class="text-info money-transfer">
                        {!! format_amount_by_symbol($sum['amount']*-1, $sum['currency_symbol'], $sum['currency_decimal_places'], false) !!}
                        @if($convertToPrimary && 0 !== $sum['pc_amount'] && $primaryCurrency->id !== $sum['currency_id'])
                            (~ {!! format_amount_by_symbol($sum['pc_amount']*-1, $primaryCurrency->symbol, $primaryCurrency->decimal_places) !!})@endif{{ $loop->index !== count($group['sums'])-1 ? ',' : '' }}
                        </span>
                    @else
                        {!! format_amount_by_symbol($sum['amount'], $sum['currency_symbol'], $sum['currency_decimal_places']) !!}
                        @if($convertToPrimary && 0 !== $sum['pc_amount'] && $primaryCurrency->id !== $sum['currency_id'])
                            (~ {!! format_amount_by_symbol($sum['pc_amount'], $primaryCurrency->symbol, $primaryCurrency->decimal_places) !!})@endif{{ $loop->index !== count($group['sums'])-1 ? ',' : '' }}
                   @endif
                @endforeach
            </td>
            <!-- column to span accounts + extra fields -->
            @if($showCategory && $showBudget)
                <td colspan="6" class="top-light-border">&nbsp;</td>
            @endif
            @if($showCategory XOR $showBudget)
                <td colspan="5" class="top-light-border">&nbsp;</td>
            @endif
            @if(!$showCategory && !$showBudget)
                <td colspan="4" class="top-light-border">&nbsp;</td>
            @endif
        <td class="top-light-border d-none d-md-table-cell text-end">
            <div class=""> <!-- d-none ? -->
                <button class="btn btn-sm btn-outline-secondary dropdown-toggle" type="button" id="group_menu_{{ $group['id'] }}" data-bs-toggle="dropdown" aria-expanded="false">{{ __('firefly.actions') }} <span class="caret"></span></button>
                <ul class="dropdown-menu" aria-labelledby="group_menu_{{ $group['id'] }}">
                    <li><a class="dropdown-item" href="{{ route('transactions.edit', [$group['id']]) }}?_from={{ urlencode($FF3_FROM) }}"><span class="bi bi-pencil"></span> {{ __('firefly.edit') }}</a></li>
                    <li><a class="dropdown-item" href="{{ route('transactions.delete', [$group['id']]) }}?_from={{ urlencode($FF3_FROM) }}"><span class="text-danger bi bi-trash"></span> {{ __('firefly.delete') }}</a></li>
                    <li><a class="dropdown-item clone-transaction" data-from="{{ $FF3_FROM }}" href="#" data-id="{{ $group['id'] }}"><span class="bi bi-copy"></span> {{ __('firefly.clone') }}</a></li>
                    <li><a class="dropdown-item clone-transaction-and-edit" data-from="{{ $FF3_FROM }}" href="#" data-id="{{ $group['id'] }}"><span class="bi bi-copy"></span> {{ __('firefly.clone_and_edit') }}</a></li>
                </ul>
            </div>
        </td>
        <td class="top-light-border d-none d-md-table-cell">&nbsp;</td><!-- would have checkbox -->
    </tr>
    @endif
    @foreach($group['transactions'] as $index => $transaction)
        @php $className = ''; @endphp
        @if(count($group['transactions']) === $loop->index && $group['count'] > 1)
            @php $className = 'bottom-light-border'; @endphp
       @endif
    <tr data-date="{{ $transaction['date']->format('Y-m-d') }}" data-count="{{ $group['count'] }}" data-id="{{ $group['id'] }}">
        <td class="tx-col-icon {{ $className }}">
            <span class="tx-type-icon"><x-elements.transaction-type-icon :type="$transaction['transaction_type_type']" /></span>
        </td>
        <td class="tx-col-desc {{ $className }}">
            @if($transaction['reconciled'])
                <span class="bi bi-check"></span>
            @endif
            @if(count($transaction['attachments']) > 0)
                <span class="bi bi-paperclip"></span>
            @endif
            @if(1 === $group['count'])
                <a href="{{ route('transactions.show', [$group['id']]) }}" title="{{ $transaction['description'] }}">
            @endif
            @if($group['count'] > 1)
                &nbsp;&nbsp;&nbsp;&nbsp;
            @endif
                {{ $transaction['description'] }}
            @if(1 === $group['count'])
                </a>
            @endif
            <span class="tx-meta d-md-none">{{ $transaction['date']->isoFormat($monthAndDayFormat) }} · {{ $transaction['source_account_name'] }} → {{ $transaction['destination_account_name'] }}</span>
        </td>
        <td class="tx-col-amount {{ $className }} text-end">
            <x-elements.transaction-amount
                :type="$transaction['transaction_type_type']"
                :amount="['amount' => $transaction['amount'], 'currency_id' => $transaction['currency_id'], 'currency_symbol' => $transaction['currency_symbol'], 'currency_decimal_places' => $transaction['currency_decimal_places']]"
                :foreign="['amount' => $transaction['foreign_amount'],'currency_id' => $transaction['foreign_currency_id'], 'currency_symbol' => $transaction['foreign_currency_symbol'], 'currency_decimal_places' => $transaction['foreign_currency_decimal_places']]"
                :account="$account ?? null"
                :pc-amount="$transaction['pc_amount']"
                :source-account="['type' => $transaction['source_account_type'], 'id' => $transaction['source_account_id']]"
            />
        </td>
        @if(get_app_configuration('use_running_balance', true))
        <td class="tx-col-balance d-none d-md-table-cell {{ $className }} text-end">
            <x-elements.transaction-running-balance
                :balance-dirty="($transaction['source_balance_dirty'] ?? false) || ($transaction['destination_balance_dirty'] ?? false)"
                :currency="['symbol' => $transaction['currency_symbol'],'decimal_places' => $transaction['currency_decimal_places']]"
                :foreign="['id' => $transaction['foreign_currency_id'], 'symbol' => $transaction['foreign_currency_symbol'], 'decimal_places' => $transaction['foreign_currency_decimal_places']]"
                :type="$transaction['transaction_type_type']"
                :account="$account ?? null"
                :source="['id' => $transaction['source_account_id'], 'balance_after' => $transaction['source_balance_after'], 'type' => $transaction['source_account_type']]"
                :destination="['id' => $transaction['destination_account_id'], 'balance_after' => $transaction['destination_balance_after'], 'type' => $transaction['destination_account_type']]"
            />
        </td>
        @endif
        <td class="tx-col-date d-none d-md-table-cell {{ $className }}">
            {{ $transaction['date']->isoFormat($monthAndDayFormat) }}
        </td>
        <td class="d-none d-md-table-cell {{ $className }}">
            @if('Cash account' === $transaction['source_account_type'])
                <span class="text-success">({{ __('firefly.cash') }})</span>
            @else
            <a href="{{ route('accounts.show', [$transaction['source_account_id'] ?? 1]) }}"
               title="{{ $transaction['source_account_iban'] ?? $transaction['source_account_name'] }}">{{ $transaction['source_account_name'] }}</a>
            @endif
        </td>
        <td class="d-none d-md-table-cell {{ $className }}">
            @if('Cash account' == $transaction['destination_account_type'])
                <span class="text-success">({{ __('firefly.cash') }})</span>
            @else
                <a href="{{ route('accounts.show', [$transaction['destination_account_id'] ?? 1]) }}" title="{{ $transaction['destination_account_iban'] ?? $transaction['destination_account_name'] }}">{{ $transaction['destination_account_name'] }}</a>
            @endif
        </td>
        @if($showCategory)
            <td class="d-none d-md-table-cell {{ $className }}">
                @if(null !== $transaction['category_id'])
                    <a href="{{ route('categories.show', [$transaction['category_id']]) }}" title="{{ $transaction['category_name'] }}">{{ $transaction['category_name'] }}</a>
                @endif
            </td>
        @endif
        @if($showBudget)
            <td class="d-none d-md-table-cell {{ $className }}">
                @if(null !== $transaction['budget_id'])
                <a href="{{ route('budgets.show', [$transaction['budget_id']]) }}"
                   title="{{ $transaction['budget_name'] }}">{{ $transaction['budget_name'] }}</a>
                @endif
            </td>
        @endif

        @if(1 === $group['count'])
        <td class="d-none d-md-table-cell {{ $className }} text-end">
                <button class="btn btn-sm btn-outline-secondary dropdown-toggle" type="button" id="journal_menu_{{ $transaction['transaction_journal_id'] }}" data-bs-toggle="dropdown" aria-expanded="false">{{ __('firefly.actions') }} <span class="caret"></span></button>
                <ul class="dropdown-menu" aria-labelledby="journal_menu_{{ $transaction['transaction_journal_id'] }}">
                    <li><a class="dropdown-item" href="{{ route('transactions.edit', [$group['id']]) }}?_from={{ urlencode($FF3_FROM) }}"><span class="bi bi-pencil"></span> {{ __('firefly.edit') }}</a></li>
                    @if($transaction['transaction_type_type'] !== 'Opening balance' && $transaction['transaction_type_type'] !== 'Liability credit')
                        <li><a class="dropdown-item" href="{{ route('transactions.delete', [$group['id']]) }}?_from={{ urlencode($FF3_FROM) }}"><span class="text-danger bi bi-trash"></span> {{ __('firefly.delete') }}</a></li>
                    @endif
                    @if($transaction['transaction_type_type'] !== 'Reconciliation' and $transaction['transaction_type_type'] !== 'Opening balance' and $transaction['transaction_type_type'] !== 'Liability credit')
                        <li><a class="dropdown-item clone-transaction" data-from="{{ $FF3_FROM }}" href="#" data-id="{{ $group['id'] }}"><span class="bi bi-copy"></span> {{ __('firefly.clone') }}</a></li>
                        <li><a class="dropdown-item clone-transaction-and-edit" data-from="{{ $FF3_FROM }}" href="#" data-id="{{ $group['id'] }}"><span class="bi bi-copy"></span> {{ __('firefly.clone_and_edit') }}</a></li>
                        <li><a class="dropdown-item" href="{{ route('rules.create-from-journal', [$transaction['transaction_journal_id']]) }}"><span class="bi bi-shuffle"></span> {{ __('firefly.create_rule_from_transaction') }}</a></li>
                    @endif
                </ul>
        </td>

        @endif
        @if(1 !== $group['count'])
        <td class="d-none d-md-table-cell {{ $className }}">
            &nbsp;
        </td>
        @endif
        <td class="d-none d-md-table-cell {{ $className }}">
            @if($transaction['transaction_type_type'] !== 'Reconciliation' and $transaction['transaction_type_type'] !== 'Opening balance' and $transaction['transaction_type_type'] !== 'Liability credit')
            <div class="text-end">
                <input id="list_{{ $transaction['transaction_journal_id'] }}"
                       value="{{ $transaction['transaction_journal_id'] }}"
                       name="journals[{{ $transaction['transaction_journal_id'] }}]"
                       type="checkbox" class="mass-select form-check-inline"
                       data-value="{{ $transaction['transaction_journal_id'] }}"/>
            @endif
            </div>
        </td>
    </tr>
    @endforeach
    @endforeach
    </tbody>
    <tfoot>
    <tr>
        @if($showCategory && $showBudget)
            <td colspan="9">
                @if(method_exists($groups, 'links'))
                    {{ $groups->links('pagination.bootstrap-4') }}
                @endif
            </td>
        @endif
        @if($showCategory XOR $showBudget)
            <td colspan="8">
                @if(method_exists($groups, 'links'))
                    {{ $groups->links('pagination.bootstrap-4') }}
                @endif
            </td>
        @endif
        @if(!$showCategory && !$showBudget)
            <td colspan="7">
                @if(method_exists($groups, 'links'))
                    {{ $groups->links('pagination.bootstrap-4') }}
                @endif
            </td>
        @endif
        <td class="d-none d-md-table-cell text-end">
            <!-- Single button -->
            <div class="action-menu d-none"> <!-- d-none -->
                <button class="btn btn-sm btn-outline-secondary dropdown-toggle" type="button" id="bottom_action_menu" data-bs-toggle="dropdown" aria-expanded="false">
                    {{ __('firefly.actions') }}<span class="caret"></span>
                </button>
                <ul class="dropdown-menu" aria-labelledby="bottom_action_menu">
                    <li><a href="#" class="dropdown-item mass-edit"><span class="bi bi-pencil"></span> <span class="txt">{{ __('firefly.mass_edit') }}</span></a></li>
                    <li><a href="#" class="dropdown-item bulk-edit"><span class="bi bi-pencil-square"></span> <span class="txt">{{ __('firefly.bulk_edit') }}</span></a></li>
                    <li><a href="#" class="dropdown-item mass-delete"><span class="bi bi-trash"></span> <span class="txt">{{ __('firefly.mass_delete') }}</span></a></li>
                </ul>
            </div>
        </td>
        <td class="d-none d-md-table-cell text-end">
            <input id="list_ALL_bottom" value="1" name="select-all" type="checkbox" class="select-all form-check-inline"/>
        </td>
    </tr>
    </tfoot>
</table>
@section('scripts')
    @parent
    <script nonce="{{ $JS_NONCE }}">
        var cloneGroupUrl = '{{ route('transactions.clone') }}';
        var cloneAndEditUrl = '{{ route('transactions.clone') }}?redirect=edit';
    </script>
    @endsection
