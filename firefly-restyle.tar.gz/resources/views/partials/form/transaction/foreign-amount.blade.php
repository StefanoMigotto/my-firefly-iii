<template x-if="formBehaviour.foreignCurrencyEnabled">
    <div class="row mb-2">
        <div class="col-sm-3">
            <label class="form-label">&nbsp;</label>
            <template x-if="formStates.loadingCurrencies">
                <span class="form-control-plaintext"><div class="spinner-border spinner-border-sm" role="status">
  <span class="visually-hidden">{{ __('firefly.thinking') }}</span>
</div></span>
            </template>
            <template x-if="!formStates.loadingCurrencies">
                <select class="form-select"
                        :id="'foreign_currency_code_' + index"
                        x-model="transaction.foreign_currency_code">
                    <template x-for="currency in formData.foreignCurrencies">
                        <option :label="currency.name" :value="currency.code" :selected="transaction.foreign_currency_code == currency.code"
                                x-text="currency.name"></option>
                    </template>
                </select>
            </template>
        </div>
        <div class="col-sm-9">
            <template x-if="groupProperties.transactionType != 'transfer'">
                <label class="small form-label">{{ __('firefly.amount_foreign_if') }}</label>
            </template>
            <template x-if="groupProperties.transactionType == 'transfer'">
                <label class="small form-label">{{ __('firefly.amount_destination_account') }}</label>
            </template>
            <div class="input-group">
            <input type="number" step="any" min="0" inputmode="decimal"
                   :id="'foreign_amount_' + index"
                   :data-index="index"
                   x-bind:disabled="transaction.reconciled"
                   x-bind:readonly="transaction.reconciled"
                   :class="{'is-invalid': transaction.errors.foreign_amount.length > 0, 'input-mask' : true, 'form-control': true}"
                   x-model="transaction.foreign_amount"
                   @change="changedForeignAmount"
                   placeholder="0.00">
                <button tabindex="-1" class="btn btn-outline-secondary" type="button" @click="clearForeignAmount(index)"><em class="bi bi-trash"></em></button>
            </div>
            <template x-if="transaction.errors.foreign_amount.length > 0">
                <div class="invalid-feedback" x-text="transaction.errors.foreign_amount[0]"></div>
            </template>
        </div>
    </div>
</template>
